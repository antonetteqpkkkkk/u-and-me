import turtle
import math
import tkinter as tk
import time
import random

text_turtle = turtle.Turtle()
text_turtle.hideturtle()
text_turtle.speed(0)
text_turtle.penup()
text_turtle.color("white")
text_turtle.goto(0, -320)
text_turtle.write("I know everybody changes but I hope that we don't", align="center", font=("Century Gothic", 11, "bold"))
text_turtle.goto(0, -340)
text_turtle.write("u plus me equal a heart forever", align="center", font=("Century Gothic", 11, "bold"))
show_text = True


screen = turtle.Screen()
screen.bgcolor("purple")

t = turtle.Turtle()
t.speed(0)
t.hideturtle()
t.penup()
t.color("#ffb6c1")

for scale in range(11, 17):
    for i in range(120):
        angle = i * (math.pi * 2) / 100

        x = 16 * (math.sin(angle) ** 3) * scale
        y = (13 * math.cos(angle) - 5 * math.cos(2 * angle)
             - 2 * math.cos(3 * angle) - math.cos(4 * angle)) * scale

        t.goto(x, y)
        t.write("me + u = <3", align="center", font=("Century Gothic", 8, "bold"))



turtle.done()